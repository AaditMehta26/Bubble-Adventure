using UnityEngine;

public class GameManager : Singleton<GameManager>
{
    
}
